@extends('tamplate')

@section('conteudo')
@routes
<table class='table'>
   
    <thead>
        <tr>
            <th>id</th>
            <th>Nome</th>
            <th>endereco</th>
            <th>cep</th>
            <th>cidade</th>
            <th>estado</th>
            <th>Operações</th>
        </tr>
    </thead>

    <tbody>
        @foreach($fornecedor as $c)
        <tr>
            <td>{{ $c->id}}</td>
            <td>{{ $c->nome}}</td>
            <td>{{ $c->endereco}}</td>
            <td>{{ $c->cep}}</td>
            <td>{{ $c->cidade}}</td>
            <td>{{ $c->estado}}</td>
            <td>
                <a href="{{ route('fornecedor_alterar', ['id' => $c->id]) }}" class="btn btn-warning">Altrar</a>
                <a href="#" onclick="excluir({{ $c->id }})" class="btn btn-danger">Excluir</a>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<script>
    function excluir(id){
        if (confirm('Deseja realmente excluir o cliente ${id}? Este processo será irreversível.')){
            location.href = route('fornecedor_excluir', {'id':id});
        }
    }
</script>
@endsection